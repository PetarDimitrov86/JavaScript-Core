function attachEvents(){
    const baseUrl = `https://baas.kinvey.com/appdata/kid_ryDho3sUb`;
    const kinveyUsername = 'peshata';
    const kinveyPassword = 'softuni';
    const authHeader = { "Authorization": `Basic ${btoa(kinveyUsername + ':' + kinveyPassword)}` };

    loadCountriesTable();

    function loadCountriesTable(){
        $('#results').empty().append($('<tr>').append($('<th>').text('Name')).append($('<th>').text('Action')));
        $.ajax({
            method: "GET",
            url: baseUrl + '/Countries',
            headers: authHeader
        }).then(fillCountriesTable);
    }
    function fillCountriesTable(data){
        for (let country of data){
            $('#results').append($('<tr>')
                .append($('<td>').text(country.name).click((countryId) => showCountryTowns(country._id)))
                .append($('<td>').append($('<button>').text('Delete').click((countryId) => deleteCountry(country._id)))));
        }

        function deleteCountry(id){
            $.ajax({
                method: "DELETE",
                url: baseUrl + `/Countries/${id}`,
                headers: authHeader
            })
                .then(loadCountriesTable)
        }

        function showCountryTowns(id) {
            let townsFromCountryUrl = `${baseUrl}/Towns/?query={"countryId":"${id}"}`;
            $.get({
                url: townsFromCountryUrl,
                headers: authHeader
            }).then((data) => {
                $('#countryTowns').empty();
                if (data.length > 0){
                    for (let town of data)
                        $('#countryTowns').append($('<li>').text(town.name))
                }
                else {
                    $('#countryTowns').append($('<li>').text('No towns for current country'))
                }
            });
        }
    }

    $('#btnSubmit').click(createCountry);

    function createCountry(){
        let name = $('#name').val();
        if (name !== ''){
            $.post({
                url: baseUrl + '/Countries',
                data: JSON.stringify({ name: name }),
                contentType: 'application/json',
                headers: authHeader
            })
                .then(() => {
                $('#name').val('');
                loadCountriesTable();
                });
        }
    }
}