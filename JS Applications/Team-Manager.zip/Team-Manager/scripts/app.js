$(() => {
    const app = Sammy('#main', function () {
        this.use('Handlebars', 'hbs');

        this.get('index.html', displayHome);
        this.get('#/home', displayHome);

        function displayHome(ctx) {
            ctx.loadPartials({
                header: './templates/common/header.hbs',
                footer: './templates/common/footer.hbs'
            })
                .then(function() {
                    ctx.loggedIn = sessionStorage.getItem('authtoken') !== null;
                    ctx.username = sessionStorage.getItem('username');
                    this.partial('./templates/home/home.hbs')
                })
        }

        this.get('#/about', function(ctx) {
            ctx.loadPartials({
                header: './templates/common/header.hbs',
                footer: './templates/common/footer.hbs'
            })
                .then(function() {
                    ctx.loggedIn = sessionStorage.getItem('authtoken') !== null;
                    ctx.username = sessionStorage.getItem('username');
                    this.partial('./templates/about/about.hbs')
                })
        });

        this.get('#/login', function(ctx) {
            ctx.loadPartials({
                header: './templates/common/header.hbs',
                footer: './templates/common/footer.hbs',
                loginForm: './templates/login/loginForm.hbs'
            })
                .then(function() {
                    ctx.loggedIn = sessionStorage.getItem('authtoken') !== null;
                    ctx.username = sessionStorage.getItem('username');
                    this.partial('./templates/login/loginPage.hbs')
                })
        });

        this.post('#/login', function(ctx) {
            let username = ctx.params.username;
            let password = ctx.params.password;
            auth.login(username, password)
                .then(function(data) {
                    auth.saveSession(data);
                    auth.showInfo('Successfully logged in as ' + username);
                    displayHome(ctx)
                })
                .catch(auth.handleError)
        });

        this.get('#/logout', function(ctx) {
            auth.logout()
                .then(function() {
                    auth.showInfo('Successfully logged out.');
                    sessionStorage.clear();
                    displayHome(ctx);
                })
                .catch(auth.handleError);
        })
    });
    app.run();
});