import Entity from './entity';
import Dog from './dog';
import Person from './person';
import Student from'./student';

result.Entity = Entity;
result.Dog = Dog;
result.Person = Person;
result.Student = Student;